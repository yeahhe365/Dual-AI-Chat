
import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, MessageSender, MessagePurpose } from './types';
import { generateResponse, generateResponseStream, StreamEvent } from './services/geminiService';
import ChatInput from './components/ChatInput';
import MessageBubble from './components/MessageBubble';
import Notepad from './components/Notepad';
import {
  MODELS,
  DEFAULT_MODEL_API_NAME,
  COGNITO_SYSTEM_PROMPT_HEADER,
  MUSE_SYSTEM_PROMPT_HEADER,
  DEFAULT_MANUAL_FIXED_TURNS,
  MIN_MANUAL_FIXED_TURNS,
  MAX_MANUAL_FIXED_TURNS,
  MAX_AI_DRIVEN_DISCUSSION_TURNS_PER_MODEL,
  INITIAL_NOTEPAD_CONTENT,
  NOTEPAD_INSTRUCTION_PROMPT_PART,
  NOTEPAD_UPDATE_TAG_START,
  NOTEPAD_UPDATE_TAG_END,
  DISCUSSION_COMPLETE_TAG,
  AI_DRIVEN_DISCUSSION_INSTRUCTION_PROMPT_PART,
  DiscussionMode,
  // AiModel type is implicitly used via MODELS array
} from './constants';
import { BotMessageSquare, AlertTriangle, RefreshCcw, SlidersHorizontal, Cpu, MessagesSquare, Bot, Activity } from 'lucide-react';

interface ParsedAIResponse {
  spokenText: string;
  newNotepadContent: string | null;
  discussionShouldEnd?: boolean;
}

const parseAIResponse = (responseText: string): ParsedAIResponse => {
  let currentText = responseText.trim();
  let spokenText = "";
  let newNotepadContent: string | null = null;
  let discussionShouldEnd = false;

  let notepadActionText = "";
  let discussionActionText = "";

  const notepadStartIndex = currentText.lastIndexOf(NOTEPAD_UPDATE_TAG_START);
  const notepadEndIndex = currentText.lastIndexOf(NOTEPAD_UPDATE_TAG_END);

  if (notepadStartIndex !== -1 && notepadEndIndex !== -1 && notepadEndIndex > notepadStartIndex && currentText.endsWith(NOTEPAD_UPDATE_TAG_END)) {
    newNotepadContent = currentText.substring(notepadStartIndex + NOTEPAD_UPDATE_TAG_START.length, notepadEndIndex).trim();
    spokenText = currentText.substring(0, notepadStartIndex).trim();

    if (newNotepadContent) {
        notepadActionText = "更新了记事本";
    } else {
        // This case might be too specific or noisy. Consider if it's truly needed.
        // notepadActionText = "尝试更新记事本但内容为空"; 
    }
  } else {
    spokenText = currentText;
  }

  if (spokenText.includes(DISCUSSION_COMPLETE_TAG)) {
    discussionShouldEnd = true;
    spokenText = spokenText.replace(new RegExp(DISCUSSION_COMPLETE_TAG.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), "").trim();
    discussionActionText = "建议结束讨论";
  }

  // Improved placeholder text generation
  if (!spokenText.trim() && (notepadActionText || discussionActionText)) {
    if (notepadActionText && discussionActionText) {
      spokenText = `(AI ${notepadActionText}并${discussionActionText})`;
    } else if (notepadActionText) {
      spokenText = `(AI ${notepadActionText})`;
    } else { // Only discussionActionText
      spokenText = `(AI ${discussionActionText})`;
    }
  } else if (!spokenText.trim() && newNotepadContent === null && !discussionShouldEnd) {
     // Only set this placeholder if no other action (notepad, discussion end) was taken AND no text response
    spokenText = "(AI 未提供额外文本回复)";
  }


  return { spokenText: spokenText.trim(), newNotepadContent, discussionShouldEnd };
};


const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1]);
    };
    reader.onerror = (error) => reject(error);
  });
};

const generateUniqueId = () => Date.now().toString() + Math.random().toString(36).substr(2, 9);

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isApiKeyMissing, setIsApiKeyMissing] = useState<boolean>(false);
  const [currentTotalProcessingTimeMs, setCurrentTotalProcessingTimeMs] = useState<number>(0);

  const [notepadContent, setNotepadContent] = useState<string>(INITIAL_NOTEPAD_CONTENT);
  const [lastNotepadUpdateBy, setLastNotepadUpdateBy] = useState<MessageSender | null>(null);

  const [selectedModelApiName, setSelectedModelApiName] = useState<string>(DEFAULT_MODEL_API_NAME);
  const [isThinkingBudgetEnabled, setIsThinkingBudgetEnabled] = useState<boolean>(true); // Default to quality (budget enabled)
  const [discussionMode, setDiscussionMode] = useState<DiscussionMode>(DiscussionMode.FixedTurns);
  const [manualFixedTurns, setManualFixedTurns] = useState<number>(DEFAULT_MANUAL_FIXED_TURNS);

  const [showThinkingProcess, setShowThinkingProcess] = useState<boolean>(false); // For streaming
  const [currentStreamingMessageId, setCurrentStreamingMessageId] = useState<string | null>(null);


  const chatContainerRef = useRef<HTMLDivElement>(null);
  const currentQueryStartTimeRef = useRef<number | null>(null);
  const cancelRequestRef = useRef<boolean>(false);

  const currentModelDetails = MODELS.find(m => m.apiName === selectedModelApiName) || MODELS[0];
  const modelSupportsThinkingBudget = currentModelDetails.supportsThinkingBudget;

  const addMessage = (
    text: string,
    sender: MessageSender,
    purpose: MessagePurpose,
    durationMs?: number,
    image?: ChatMessage['image'],
    isStreamingInitial: boolean = false,
    explicitIdToUse?: string 
  ): string => {
    const messageId = explicitIdToUse || generateUniqueId();
    setMessages(prev => [...prev, {
      id: messageId, // Use this as the React key, always unique
      text,
      sender,
      purpose,
      timestamp: new Date(),
      durationMs,
      image,
      isStreaming: isStreamingInitial,
      explicitId: messageId // This is what we use to target updates
    }]);
    return messageId; 
  };

  const getWelcomeMessageText = (
    modelName: string,
    currentDiscussionMode: DiscussionMode,
    currentManualFixedTurns: number
  ) => {
    let modeDescription = "";
     if (currentDiscussionMode === DiscussionMode.FixedTurns) {
      modeDescription = `固定轮次对话 (${currentManualFixedTurns}轮)`;
    } else {
      modeDescription = "AI驱动(不固定轮次)对话";
    }
    return `欢迎使用Dual AI Chat！当前模式: ${modeDescription}。在下方输入您的问题或上传图片。${MessageSender.Cognito} 和 ${MessageSender.Muse} 将进行讨论，并可能使用右侧的共享记事本。然后 ${MessageSender.Cognito} 会给您回复。当前模型: ${modelName}`;
  };

  const initializeChat = () => {
    setMessages([]);
    setNotepadContent(INITIAL_NOTEPAD_CONTENT);
    setLastNotepadUpdateBy(null);
    setCurrentStreamingMessageId(null);
    cancelRequestRef.current = false; // Reset cancellation flag

    if (!process.env.API_KEY) {
      setIsApiKeyMissing(true);
      addMessage(
        "严重警告：API_KEY 未配置。请确保设置 API_KEY 环境变量，以便应用程序正常运行。",
        MessageSender.System,
        MessagePurpose.SystemNotification
      );
    } else {
      setIsApiKeyMissing(false);
      addMessage(
        getWelcomeMessageText(currentModelDetails.name, discussionMode, manualFixedTurns),
        MessageSender.System,
        MessagePurpose.SystemNotification
      );
    }
  };

  useEffect(() => {
    initializeChat();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

   useEffect(() => {
     const welcomeMessage = messages.find(msg => msg.sender === MessageSender.System && msg.text.startsWith("欢迎使用Dual AI Chat！"));
     if (welcomeMessage && !isApiKeyMissing) {
        setMessages(msgs => msgs.map(msg =>
            // Use explicitId for matching if it exists, otherwise id (though welcome won't have explicitId from addMessage)
            (msg.explicitId || msg.id) === (welcomeMessage.explicitId || welcomeMessage.id) 
            ? {...msg, text: getWelcomeMessageText(currentModelDetails.name, discussionMode, manualFixedTurns) }
            : msg
        ));
     }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentModelDetails.name, isApiKeyMissing, discussionMode, manualFixedTurns]);


  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    let intervalId: number | undefined;
    if (isLoading && currentQueryStartTimeRef.current) {
      intervalId = window.setInterval(() => {
        if (currentQueryStartTimeRef.current && !cancelRequestRef.current) { 
          setCurrentTotalProcessingTimeMs(performance.now() - currentQueryStartTimeRef.current);
        }
      }, 100);
    } else {
      if (intervalId) clearInterval(intervalId);
      if (!isLoading && currentQueryStartTimeRef.current !== null) {
         // Finalize time if stopped not by loading finishing but by cancellation or error
         setCurrentTotalProcessingTimeMs(performance.now() - currentQueryStartTimeRef.current);
         // Do not nullify currentQueryStartTimeRef.current here; it's reset in handleSendMessage's finally block
      }
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isLoading]);

  const handleClearChat = () => {
    if (isLoading) {
      cancelRequestRef.current = true; 
    }
    setIsLoading(false); 

    setCurrentTotalProcessingTimeMs(0);
    if (currentQueryStartTimeRef.current) {
        currentQueryStartTimeRef.current = null;
    }

    setMessages([]); 
    setNotepadContent(INITIAL_NOTEPAD_CONTENT);
    setLastNotepadUpdateBy(null);
    setCurrentStreamingMessageId(null);
    
     if (!isApiKeyMissing) {
       addMessage(
        getWelcomeMessageText(currentModelDetails.name, discussionMode, manualFixedTurns),
        MessageSender.System,
        MessagePurpose.SystemNotification
      );
    } else {
         addMessage(
            "严重警告：API_KEY 未配置。请确保设置 API_KEY 环境变量，以便应用程序正常运行。",
            MessageSender.System,
            MessagePurpose.SystemNotification
      );
    }
  };

  const handleManualFixedTurnsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = parseInt(e.target.value, 10);
    if (isNaN(value)) {
      value = DEFAULT_MANUAL_FIXED_TURNS;
    }
    value = Math.max(MIN_MANUAL_FIXED_TURNS, Math.min(MAX_MANUAL_FIXED_TURNS, value));
    setManualFixedTurns(value);
  };

  // Helper to update streaming message
  const updateStreamingMessage = (
      idToUpdate: string, 
      chunkText?: string, 
      finalFullText?: string, 
      duration?: number, 
      errorText?: string, 
      isApiError?:boolean
    ) => {
    setMessages(prev => prev.map(m => {
      if (m.explicitId === idToUpdate) { // Target using explicitId
        let newText = m.text;
        if (chunkText) newText += chunkText;
        if (finalFullText) newText = finalFullText; 
        if (errorText) newText = `错误: ${errorText}`; // Prepend "错误:" to make it clear

        return {
          ...m,
          text: newText,
          durationMs: finalFullText || errorText ? duration : m.durationMs,
          isStreaming: !(finalFullText || errorText), 
          sender: errorText ? MessageSender.System : m.sender, 
          purpose: errorText ? MessagePurpose.SystemNotification : m.purpose, 
        };
      }
      return m;
    }));
    if (isApiError) setIsApiKeyMissing(true);
  };

  const handleStopGenerating = () => {
    if (isLoading) {
      cancelRequestRef.current = true;
      // isLoading will be set to false in the finally block of handleSendMessage
      // A system message about cancellation will also be added there if needed.
    }
  };

  const handleSendMessage = async (userInput: string, imageFile?: File | null) => {
    if (isApiKeyMissing || isLoading) return;
    if (!userInput.trim() && !imageFile) return;

    cancelRequestRef.current = false;
    setIsLoading(true);
    currentQueryStartTimeRef.current = performance.now();
    setCurrentTotalProcessingTimeMs(0);

    let userImageForDisplay: ChatMessage['image'] | undefined = undefined;
    if (imageFile) {
      const dataUrl = URL.createObjectURL(imageFile);
      userImageForDisplay = { dataUrl, name: imageFile.name, type: imageFile.type };
    }

    addMessage(userInput, MessageSender.User, MessagePurpose.UserInput, undefined, userImageForDisplay);

    const discussionLog: string[] = [];
    let lastTurnTextForLog = "";
    // Correctly use isThinkingBudgetEnabled. If true, budget is on (quality), so don't pass thinkingBudget:0.
    // If false, budget is off (fast), so pass thinkingBudget:0.
    const shouldApplyBudgetZeroForApi = modelSupportsThinkingBudget && !isThinkingBudgetEnabled;


    let imageApiPart: { inlineData: { mimeType: string; data: string } } | undefined = undefined;
    if (imageFile) {
      try {
        const base64Data = await fileToBase64(imageFile);
        imageApiPart = { inlineData: { mimeType: imageFile.type, data: base64Data } };
      } catch (error) {
        console.error("Error converting file to base64:", error);
        addMessage("图片处理失败，请重试。", MessageSender.System, MessagePurpose.SystemNotification);
        setIsLoading(false); 
        currentQueryStartTimeRef.current = null; // Reset timer as operation failed early
        return; 
      }
    }

    const imageInstructionForAI = imageApiPart ? "用户还提供了一张图片。请在您的分析和回复中同时考虑此图片和文本查询。" : "";
    const discussionModeInstruction = discussionMode === DiscussionMode.AiDriven ? AI_DRIVEN_DISCUSSION_INSTRUCTION_PROMPT_PART : "";

    try {
      if (cancelRequestRef.current) return;

      const commonPromptInstructions = () => NOTEPAD_INSTRUCTION_PROMPT_PART.replace('{notepadContent}', notepadContent) + discussionModeInstruction;

      // --- Cognito Initial Turn ---
      addMessage(`${MessageSender.Cognito} 正在为 ${MessageSender.Muse} 准备第一个观点 (使用 ${currentModelDetails.name})...`, MessageSender.System, MessagePurpose.SystemNotification);
      const cognitoInitialTaskInstruction = `用户的查询 (中文) 是: "${userInput}". ${imageInstructionForAI} 请针对此查询提供您的初步想法或分析，以便 ${MessageSender.Muse} (创意型AI) 可以回应并与您开始讨论。用中文回答。`;
      const cognitoPrompt = `${cognitoInitialTaskInstruction}\n${commonPromptInstructions()}`;

      let cognitoFullText = "";
      let cognitoDuration = 0;
      let cognitoParsedResponse: ParsedAIResponse;
      const cognitoMsgId = generateUniqueId(); // Generate ID upfront

      if (showThinkingProcess) {
        addMessage("", MessageSender.Cognito, MessagePurpose.CognitoToMuse, undefined, undefined, true, cognitoMsgId);
        setCurrentStreamingMessageId(cognitoMsgId);
        for await (const event of generateResponseStream(cognitoPrompt, selectedModelApiName, COGNITO_SYSTEM_PROMPT_HEADER, shouldApplyBudgetZeroForApi, imageApiPart)) {
          if (cancelRequestRef.current) break;
          if (event.chunkText) updateStreamingMessage(cognitoMsgId, event.chunkText);
          if (event.finalFullText !== undefined) { cognitoFullText = event.finalFullText; cognitoDuration = event.durationMs || 0; }
          if (event.error) {
            updateStreamingMessage(cognitoMsgId, undefined, undefined, event.durationMs, event.error, event.isApiKeyError);
            throw event.isApiKeyError ? Object.assign(new Error(event.error), {isApiKeyError: true}) : new Error(event.error);
          }
        }
        if (cancelRequestRef.current) return; // Exit if cancelled during stream
        cognitoParsedResponse = parseAIResponse(cognitoFullText);
        updateStreamingMessage(cognitoMsgId, undefined, cognitoParsedResponse.spokenText, cognitoDuration);
      } else {
        if (cancelRequestRef.current) return;
        const cognitoResultRaw = await generateResponse(cognitoPrompt, selectedModelApiName, COGNITO_SYSTEM_PROMPT_HEADER, shouldApplyBudgetZeroForApi, imageApiPart);
        if (cancelRequestRef.current) return;
        if (cognitoResultRaw.error) { if(cognitoResultRaw.error.includes("API key not valid")) {setIsApiKeyMissing(true); throw Object.assign(new Error(cognitoResultRaw.text), {isApiKeyError: true});} throw new Error(cognitoResultRaw.text); }
        cognitoParsedResponse = parseAIResponse(cognitoResultRaw.text);
        cognitoDuration = cognitoResultRaw.durationMs;
        // Add non-streaming message with its own unique ID (not cognitoMsgId)
        addMessage(cognitoParsedResponse.spokenText, MessageSender.Cognito, MessagePurpose.CognitoToMuse, cognitoDuration);
      }
       setCurrentStreamingMessageId(null); // Clear after this stream/non-stream segment
       if (cancelRequestRef.current) return;

      if (cognitoParsedResponse.newNotepadContent !== null) { setNotepadContent(cognitoParsedResponse.newNotepadContent); setLastNotepadUpdateBy(MessageSender.Cognito); }
      lastTurnTextForLog = cognitoParsedResponse.spokenText;
      discussionLog.push(`${MessageSender.Cognito}: ${lastTurnTextForLog}`);
      let previousAISignaledStop = discussionMode === DiscussionMode.AiDriven && (cognitoParsedResponse.discussionShouldEnd || false);
      if (previousAISignaledStop) addMessage(`${MessageSender.Cognito} 已建议结束讨论。等待 ${MessageSender.Muse} 的回应。`, MessageSender.System, MessagePurpose.SystemNotification);

      const maxTurnsForLoop = discussionMode === DiscussionMode.AiDriven ? MAX_AI_DRIVEN_DISCUSSION_TURNS_PER_MODEL : manualFixedTurns;

      for (let turn = 0; turn < maxTurnsForLoop; turn++) {
        if (cancelRequestRef.current) break;

        // --- Muse Turn ---
        addMessage(`${MessageSender.Muse} 正在回应 ${MessageSender.Cognito} (使用 ${currentModelDetails.name})...`, MessageSender.System, MessagePurpose.SystemNotification);
        let musePrompt = `${MUSE_SYSTEM_PROMPT_HEADER} 用户的查询 (中文) 是: "${userInput}". ${imageInstructionForAI} 当前讨论 (均为中文):\n${discussionLog.join("\n")}\n${MessageSender.Cognito} (逻辑AI) 刚刚说 (中文): "${lastTurnTextForLog}". 请回复 ${MessageSender.Cognito}。继续讨论。保持您的回复简洁并使用中文。\n${commonPromptInstructions()}`;
        if (discussionMode === DiscussionMode.AiDriven && previousAISignaledStop) musePrompt += `\n${MessageSender.Cognito} 已包含 ${DISCUSSION_COMPLETE_TAG} 建议结束讨论。如果您同意，请在您的回复中也包含 ${DISCUSSION_COMPLETE_TAG}。否则，请继续讨论。`;

        let museFullText = "";
        let museDuration = 0;
        let museParsedResponse: ParsedAIResponse;
        const museMsgId = generateUniqueId();

        if (showThinkingProcess) {
          addMessage("", MessageSender.Muse, MessagePurpose.MuseToCognito, undefined, undefined, true, museMsgId);
          setCurrentStreamingMessageId(museMsgId);
          for await (const event of generateResponseStream(musePrompt, selectedModelApiName, MUSE_SYSTEM_PROMPT_HEADER, shouldApplyBudgetZeroForApi, imageApiPart)) {
            if (cancelRequestRef.current) break;
            if (event.chunkText) updateStreamingMessage(museMsgId, event.chunkText);
            if (event.finalFullText !== undefined) { museFullText = event.finalFullText; museDuration = event.durationMs || 0; }
            if (event.error) {
              updateStreamingMessage(museMsgId, undefined, undefined, event.durationMs, event.error, event.isApiKeyError);
              throw event.isApiKeyError ? Object.assign(new Error(event.error), {isApiKeyError: true}) : new Error(event.error);
            }
          }
          if (cancelRequestRef.current) break;
          museParsedResponse = parseAIResponse(museFullText);
          updateStreamingMessage(museMsgId, undefined, museParsedResponse.spokenText, museDuration);
        } else {
          if (cancelRequestRef.current) break;
          const museResultRaw = await generateResponse(musePrompt, selectedModelApiName, MUSE_SYSTEM_PROMPT_HEADER, shouldApplyBudgetZeroForApi, imageApiPart);
          if (cancelRequestRef.current) break;
          if (museResultRaw.error) { if(museResultRaw.error.includes("API key not valid")) {setIsApiKeyMissing(true); throw Object.assign(new Error(museResultRaw.text), {isApiKeyError: true});} throw new Error(museResultRaw.text); }
          museParsedResponse = parseAIResponse(museResultRaw.text);
          museDuration = museResultRaw.durationMs;
          addMessage(museParsedResponse.spokenText, MessageSender.Muse, MessagePurpose.MuseToCognito, museDuration);
        }
        setCurrentStreamingMessageId(null);
        if (cancelRequestRef.current) break;

        if (museParsedResponse.newNotepadContent !== null) { setNotepadContent(museParsedResponse.newNotepadContent); setLastNotepadUpdateBy(MessageSender.Muse); }
        lastTurnTextForLog = museParsedResponse.spokenText;
        discussionLog.push(`${MessageSender.Muse}: ${lastTurnTextForLog}`);

        if (discussionMode === DiscussionMode.AiDriven) {
          if (museParsedResponse.discussionShouldEnd) {
            if (previousAISignaledStop) { addMessage(`双方AI (${MessageSender.Cognito} 和 ${MessageSender.Muse}) 已同意结束讨论。`, MessageSender.System, MessagePurpose.SystemNotification); break; }
            previousAISignaledStop = true; addMessage(`${MessageSender.Muse} 已建议结束讨论。等待 ${MessageSender.Cognito} 的回应。`, MessageSender.System, MessagePurpose.SystemNotification);
          } else { previousAISignaledStop = false; }
        }
        if (discussionMode === DiscussionMode.FixedTurns && turn === maxTurnsForLoop - 1) break;
        if (cancelRequestRef.current) break;

        // --- Cognito Reply Turn ---
        addMessage(`${MessageSender.Cognito} 正在回应 ${MessageSender.Muse} (使用 ${currentModelDetails.name})...`, MessageSender.System, MessagePurpose.SystemNotification);
        let cognitoReplyPrompt = `${COGNITO_SYSTEM_PROMPT_HEADER} 用户的查询 (中文) 是: "${userInput}". ${imageInstructionForAI} 当前讨论 (均为中文):\n${discussionLog.join("\n")}\n${MessageSender.Muse} (创意AI) 刚刚说 (中文): "${lastTurnTextForLog}". 请回复 ${MessageSender.Muse}。继续讨论。保持您的回复简洁并使用中文。\n${commonPromptInstructions()}`;
        if (discussionMode === DiscussionMode.AiDriven && previousAISignaledStop) cognitoReplyPrompt += `\n${MessageSender.Muse} 已包含 ${DISCUSSION_COMPLETE_TAG} 建议结束讨论。如果您同意，请在您的回复中也包含 ${DISCUSSION_COMPLETE_TAG}。否则，请继续讨论。`;

        let cognitoReplyFullText = "";
        let cognitoReplyDuration = 0;
        let cognitoReplyParsedResponse: ParsedAIResponse;
        const cognitoReplyMsgId = generateUniqueId();

        if (showThinkingProcess) {
          addMessage("", MessageSender.Cognito, MessagePurpose.CognitoToMuse, undefined, undefined, true, cognitoReplyMsgId);
          setCurrentStreamingMessageId(cognitoReplyMsgId);
          for await (const event of generateResponseStream(cognitoReplyPrompt, selectedModelApiName, COGNITO_SYSTEM_PROMPT_HEADER, shouldApplyBudgetZeroForApi, imageApiPart)) {
            if (cancelRequestRef.current) break;
            if (event.chunkText) updateStreamingMessage(cognitoReplyMsgId, event.chunkText);
            if (event.finalFullText !== undefined) { cognitoReplyFullText = event.finalFullText; cognitoReplyDuration = event.durationMs || 0; }
            if (event.error) {
              updateStreamingMessage(cognitoReplyMsgId, undefined, undefined, event.durationMs, event.error, event.isApiKeyError);
              throw event.isApiKeyError ? Object.assign(new Error(event.error), {isApiKeyError: true}) : new Error(event.error);
            }
          }
          if (cancelRequestRef.current) break;
          cognitoReplyParsedResponse = parseAIResponse(cognitoReplyFullText);
          updateStreamingMessage(cognitoReplyMsgId, undefined, cognitoReplyParsedResponse.spokenText, cognitoReplyDuration);
        } else {
          if (cancelRequestRef.current) break;
          const cognitoReplyResultRaw = await generateResponse(cognitoReplyPrompt, selectedModelApiName, COGNITO_SYSTEM_PROMPT_HEADER, shouldApplyBudgetZeroForApi, imageApiPart);
          if (cancelRequestRef.current) break;
          if (cognitoReplyResultRaw.error) { if(cognitoReplyResultRaw.error.includes("API key not valid")) {setIsApiKeyMissing(true); throw Object.assign(new Error(cognitoReplyResultRaw.text), {isApiKeyError: true});} throw new Error(cognitoReplyResultRaw.text); }
          cognitoReplyParsedResponse = parseAIResponse(cognitoReplyResultRaw.text);
          cognitoReplyDuration = cognitoReplyResultRaw.durationMs;
          addMessage(cognitoReplyParsedResponse.spokenText, MessageSender.Cognito, MessagePurpose.CognitoToMuse, cognitoReplyDuration);
        }
        setCurrentStreamingMessageId(null);
        if (cancelRequestRef.current) break;

        if (cognitoReplyParsedResponse.newNotepadContent !== null) { setNotepadContent(cognitoReplyParsedResponse.newNotepadContent); setLastNotepadUpdateBy(MessageSender.Cognito); }
        lastTurnTextForLog = cognitoReplyParsedResponse.spokenText;
        discussionLog.push(`${MessageSender.Cognito}: ${lastTurnTextForLog}`);

        if (discussionMode === DiscussionMode.AiDriven) {
          if (cognitoReplyParsedResponse.discussionShouldEnd) {
            if (previousAISignaledStop) { addMessage(`双方AI (${MessageSender.Muse} 和 ${MessageSender.Cognito}) 已同意结束讨论。`, MessageSender.System, MessagePurpose.SystemNotification); break; }
            previousAISignaledStop = true; addMessage(`${MessageSender.Cognito} 已建议结束讨论。等待 ${MessageSender.Muse} 的回应。`, MessageSender.System, MessagePurpose.SystemNotification);
          } else { previousAISignaledStop = false; }
        }
        if (turn === maxTurnsForLoop - 1 && discussionMode === DiscussionMode.AiDriven) addMessage(`已达到AI驱动模式下的最大讨论轮次。 ${MessageSender.Cognito} 将准备最终答复。`, MessageSender.System, MessagePurpose.SystemNotification);
      } 
      if (cancelRequestRef.current) return;

      // --- Cognito Final Answer ---
      addMessage(`${MessageSender.Cognito} 正在综合讨论内容，准备最终答案 (使用 ${currentModelDetails.name})...`, MessageSender.System, MessagePurpose.SystemNotification);
      const finalAnswerPrompt = `${COGNITO_SYSTEM_PROMPT_HEADER} 用户最初的查询 (中文) 是: "${userInput}". ${imageInstructionForAI} 您 (${MessageSender.Cognito}) 和 ${MessageSender.Muse} 进行了以下讨论 (均为中文):\n${discussionLog.join("\n")}\n基于整个交流过程和共享记事本的最终状态，综合所有关键点，并为用户制定一个全面、有用的最终答案。直接回复用户，而不是 ${MessageSender.Muse}。确保答案结构良好，易于理解，并使用中文。如果相关，您可以在答案中引用记事本。如果认为有必要，您也可以使用标准的记事本更新说明最后一次更新记事本。\n${commonPromptInstructions()}`;

      let finalAnswerFullText = "";
      let finalAnswerDuration = 0;
      let finalAnswerParsedResponse: ParsedAIResponse;
      const finalAnswerMsgId = generateUniqueId();

      if (showThinkingProcess) {
        addMessage("", MessageSender.Cognito, MessagePurpose.FinalResponse, undefined, undefined, true, finalAnswerMsgId);
        setCurrentStreamingMessageId(finalAnswerMsgId);
        for await (const event of generateResponseStream(finalAnswerPrompt, selectedModelApiName, COGNITO_SYSTEM_PROMPT_HEADER, shouldApplyBudgetZeroForApi, imageApiPart)) {
          if (cancelRequestRef.current) break;
          if (event.chunkText) updateStreamingMessage(finalAnswerMsgId, event.chunkText);
          if (event.finalFullText !== undefined) { finalAnswerFullText = event.finalFullText; finalAnswerDuration = event.durationMs || 0; }
          if (event.error) {
            updateStreamingMessage(finalAnswerMsgId, undefined, undefined, event.durationMs, event.error, event.isApiKeyError);
            throw event.isApiKeyError ? Object.assign(new Error(event.error), {isApiKeyError: true}) : new Error(event.error);
          }
        }
        if (cancelRequestRef.current) return;
        finalAnswerParsedResponse = parseAIResponse(finalAnswerFullText);
        updateStreamingMessage(finalAnswerMsgId, undefined, finalAnswerParsedResponse.spokenText, finalAnswerDuration);
      } else {
        if (cancelRequestRef.current) return;
        const finalAnswerResultRaw = await generateResponse(finalAnswerPrompt, selectedModelApiName, COGNITO_SYSTEM_PROMPT_HEADER, shouldApplyBudgetZeroForApi, imageApiPart);
        if (cancelRequestRef.current) return;
        if (finalAnswerResultRaw.error) { if(finalAnswerResultRaw.error.includes("API key not valid")) {setIsApiKeyMissing(true); throw Object.assign(new Error(finalAnswerResultRaw.text), {isApiKeyError: true});} throw new Error(finalAnswerResultRaw.text); }
        finalAnswerParsedResponse = parseAIResponse(finalAnswerResultRaw.text);
        finalAnswerDuration = finalAnswerResultRaw.durationMs;
        addMessage(finalAnswerParsedResponse.spokenText, MessageSender.Cognito, MessagePurpose.FinalResponse, finalAnswerDuration);
      }
      setCurrentStreamingMessageId(null);
      if (cancelRequestRef.current) return;

      if (finalAnswerParsedResponse.newNotepadContent !== null) { setNotepadContent(finalAnswerParsedResponse.newNotepadContent); setLastNotepadUpdateBy(MessageSender.Cognito); }

    } catch (error) {
      if (cancelRequestRef.current) {
         // Error likely occurred during stream setup or parsing before a cancel check, or it's an API key error thrown from stream
        if (error instanceof Error && ((error as any).isApiKeyError)) {
          setIsApiKeyMissing(true);
          // An API key error message would have already been added by updateStreamingMessage or the non-streaming path
        }
      } else {
        console.error("聊天流程中发生错误:", error);
        const errorMessageText = error instanceof Error ? error.message : "处理您的请求时发生意外错误。";
        // Avoid adding duplicate error if it was already handled by updateStreamingMessage
        if (!currentStreamingMessageId) { 
          const displayError = (error instanceof Error && ((error as any).isApiKeyError || errorMessageText.includes("API_KEY 未配置") || errorMessageText.includes("API密钥无效")))
            ? `错误：${errorMessageText} 请检查您的API密钥配置。聊天功能可能无法正常工作。`
            : `错误: ${errorMessageText}`;
          addMessage(displayError, MessageSender.System, MessagePurpose.SystemNotification, 0);
        }
         if (error instanceof Error && ((error as any).isApiKeyError || errorMessageText.includes("API_KEY 未配置") || errorMessageText.includes("API密钥无效"))) {
            setIsApiKeyMissing(true);
        }
      }
    } finally {
      const wasCancelled = cancelRequestRef.current;

      if (wasCancelled && currentStreamingMessageId) {
        // Finalize the currently streaming message if cancelled
        setMessages(prev => prev.map(m => {
          if (m.explicitId === currentStreamingMessageId) {
            const stoppedText = (m.text ? (m.text.endsWith("▋") ? m.text.slice(0, -1) : m.text) : "") + "\n(用户已停止)";
            return {
              ...m,
              text: stoppedText,
              isStreaming: false,
              durationMs: m.durationMs || (currentQueryStartTimeRef.current ? performance.now() - currentQueryStartTimeRef.current : undefined)
            };
          }
          return m;
        }));
      }
      
      setIsLoading(false);
      setCurrentStreamingMessageId(null); 

      if (userImageForDisplay?.dataUrl.startsWith('blob:')) {
        URL.revokeObjectURL(userImageForDisplay.dataUrl);
      }
      
      if (currentQueryStartTimeRef.current) {
        setCurrentTotalProcessingTimeMs(performance.now() - currentQueryStartTimeRef.current);
      }
      currentQueryStartTimeRef.current = null; 

      if (wasCancelled) {
        // Add a general cancellation message if no specific stream was active or if it's preferred
        // This ensures a system message is always present for cancellation if not handled by stream finalization
        if (!messages.some(msg => msg.text.includes("(用户已停止)"))) { // Avoid duplicate "stopped" messages
             addMessage("用户已停止AI响应。", MessageSender.System, MessagePurpose.SystemNotification);
        }
      }
    }
  };

  const Separator = () => <div className="h-6 w-px bg-gray-300 mx-1 md:mx-1.5" aria-hidden="true"></div>;

  return (
    <div className="flex flex-col h-screen bg-white shadow-2xl overflow-hidden border-x border-gray-300">
      <header className="p-4 bg-gray-50 border-b border-gray-300 flex items-center justify-between shrink-0 space-x-2 md:space-x-4 flex-wrap">
        <div className="flex items-center shrink-0">
          <BotMessageSquare size={28} className="mr-2 md:mr-3 text-sky-600" />
          <h1 className="text-xl md:text-2xl font-semibold text-sky-600">Dual AI Chat</h1>
        </div>

        <div className="flex items-center space-x-2 md:space-x-3 flex-wrap justify-end gap-y-2">
          {/* Model Selector */}
          <div className="flex items-center">
            <label htmlFor="modelSelector" className="text-sm text-gray-700 mr-1.5 flex items-center shrink-0">
              <Cpu size={18} className="mr-1 text-sky-600"/>模型:</label>
            <select id="modelSelector" value={selectedModelApiName} onChange={(e) => setSelectedModelApiName(e.target.value)}
              className="bg-white border border-gray-400 text-gray-800 text-sm rounded-md p-1.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none disabled:opacity-70 disabled:cursor-not-allowed"
              aria-label="选择AI模型" disabled={isLoading}>
              {MODELS.map((model) => (<option key={model.id} value={model.apiName}>{model.name}</option>))}
            </select>
          </div>
          <Separator />
          {/* Discussion Mode Toggle */}
          <div className="flex items-center space-x-1.5">
            <label htmlFor="discussionModeToggle" className={`flex items-center text-sm text-gray-700 ${isLoading ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer hover:text-sky-600'}`}
              title={discussionMode === DiscussionMode.FixedTurns ? "切换到不固定轮次模式" : "切换到固定轮次模式"}>
              {discussionMode === DiscussionMode.FixedTurns ? <MessagesSquare size={18} className="mr-1 text-sky-600" /> : <Bot size={18} className="mr-1 text-sky-600" />}
              <span className="mr-1 select-none shrink-0">轮数:</span>
              <div className="relative"><input type="checkbox" id="discussionModeToggle" className="sr-only peer" checked={discussionMode === DiscussionMode.AiDriven}
                  onChange={() => !isLoading && setDiscussionMode(prev => prev === DiscussionMode.FixedTurns ? DiscussionMode.AiDriven : DiscussionMode.FixedTurns)}
                  aria-label="切换对话轮数模式" disabled={isLoading} />
                <div className={`block w-10 h-6 rounded-full transition-colors ${discussionMode === DiscussionMode.AiDriven ? 'bg-sky-500' : 'bg-gray-400'} ${isLoading ? 'opacity-70' : ''}`}></div>
                <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${discussionMode === DiscussionMode.AiDriven ? 'translate-x-4' : ''}`}></div>
              </div><span className="ml-1.5 select-none shrink-0 min-w-[4rem] text-left">{discussionMode === DiscussionMode.FixedTurns ? '固定' : '不固定'}</span>
            </label>
            {discussionMode === DiscussionMode.FixedTurns && (
              <div className="flex items-center text-sm text-gray-700">
                <input type="number" id="manualFixedTurnsInput" value={manualFixedTurns} onChange={handleManualFixedTurnsChange}
                  min={MIN_MANUAL_FIXED_TURNS} max={MAX_MANUAL_FIXED_TURNS} disabled={isLoading}
                  className="w-14 bg-white border border-gray-400 text-gray-800 text-sm rounded-md p-1 text-center focus:ring-1 focus:ring-sky-500 focus:border-sky-500 outline-none disabled:opacity-70 disabled:cursor-not-allowed"/>
                <span className="ml-1 select-none">轮</span>
              </div>)}
          </div>
          <Separator />
          {/* Thinking Budget Toggle */}
          <label htmlFor="thinkingToggle"
            className={`flex items-center text-sm text-gray-700 transition-opacity ${isLoading || !modelSupportsThinkingBudget ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer hover:text-sky-600'}`}
            title={modelSupportsThinkingBudget ? (isThinkingBudgetEnabled ? "优质模式 (预算充足)" : "快速模式 (预算节约)") : "此模型不支持预算设置"}>
            <SlidersHorizontal size={18} className={`mr-1.5 ${modelSupportsThinkingBudget && isThinkingBudgetEnabled ? 'text-sky-600' : 'text-gray-400'}`} />
            <span className="mr-2 select-none shrink-0">预算:</span>
            <div className="relative"><input type="checkbox" id="thinkingToggle" className="sr-only peer" checked={isThinkingBudgetEnabled}
                onChange={() => {!isLoading && modelSupportsThinkingBudget && setIsThinkingBudgetEnabled(!isThinkingBudgetEnabled);}}
                disabled={isLoading || !modelSupportsThinkingBudget} aria-label="切换AI思考预算" />
              <div className={`block w-10 h-6 rounded-full transition-colors ${modelSupportsThinkingBudget ? (isThinkingBudgetEnabled ? 'bg-sky-500' : 'bg-gray-400') : 'bg-gray-300'} ${isLoading ? 'opacity-70' : ''}`}></div>
              <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${modelSupportsThinkingBudget && isThinkingBudgetEnabled ? 'translate-x-4' : ''}`}></div>
            </div>
          </label>
          <Separator />
          {/* Show Thinking Process Toggle */}
          <label htmlFor="thinkingProcessToggle" className={`flex items-center text-sm text-gray-700 ${isLoading ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer hover:text-sky-600'}`}
            title={showThinkingProcess ? "关闭实时更新" : "开启实时更新 (显示思考过程)"}>
            <Activity size={18} className={`mr-1.5 ${showThinkingProcess ? 'text-sky-600' : 'text-gray-400'}`} />
            <span className="mr-2 select-none shrink-0">实时:</span>
            <div className="relative">
              <input type="checkbox" id="thinkingProcessToggle" className="sr-only peer" checked={showThinkingProcess}
                onChange={() => !isLoading && setShowThinkingProcess(!showThinkingProcess)}
                disabled={isLoading} aria-label="切换实时更新显示思考过程" />
              <div className={`block w-10 h-6 rounded-full transition-colors ${showThinkingProcess ? 'bg-sky-500' : 'bg-gray-400'} ${isLoading ? 'opacity-70' : ''}`}></div>
              <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${showThinkingProcess ? 'translate-x-4' : ''}`}></div>
            </div>
          </label>
           <Separator />
          {/* Clear Chat Button */}
          <button onClick={handleClearChat} 
            className="p-2 text-gray-500 hover:text-sky-600 transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 focus:ring-offset-gray-50 rounded-md shrink-0 disabled:opacity-70 disabled:cursor-not-allowed"
            aria-label="清空会话" title="清空会话" disabled={isLoading && !cancelRequestRef.current} // Allow clear if a stop is pending
            ><RefreshCcw size={22} />
          </button>
        </div>
      </header>

      <div className="flex flex-row flex-grow overflow-hidden">
        <div className="flex flex-col w-2/3 md:w-3/5 lg:w-2/3 h-full">
          <div ref={chatContainerRef} className="flex-grow p-4 space-y-4 overflow-y-auto bg-gray-200 scroll-smooth">
            {messages.map((msg) => (
              <MessageBubble key={msg.explicitId || msg.id} message={msg} />
            ))}
          </div>
          <ChatInput
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            isApiKeyMissing={isApiKeyMissing}
            onStopGenerating={handleStopGenerating}
          />
        </div>
        <div className="w-1/3 md:w-2/5 lg:w-1/3 h-full bg-gray-50">
          <Notepad content={notepadContent} lastUpdatedBy={lastNotepadUpdateBy} isLoading={isLoading} />
        </div>
      </div>

      { (isLoading || (currentTotalProcessingTimeMs > 0 && currentQueryStartTimeRef.current === null)) && (
         <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 bg-white bg-opacity-90 text-gray-700 p-2 rounded-md shadow-lg text-xs z-50 border border-gray-300">
            {isLoading ? '处理中: ' : '总耗时: '} {(currentTotalProcessingTimeMs / 1000).toFixed(2)}s
        </div>
      )}
       {isApiKeyMissing &&
        !messages.some(msg => msg.text.includes("API_KEY 未配置") || msg.text.includes("API密钥无效")) &&
        !messages.some(msg => msg.text.includes("严重警告：API_KEY 未配置")) &&
        (
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 p-3 bg-red-100 text-red-700 border border-red-300 rounded-lg shadow-lg flex items-center text-sm z-50">
            <AlertTriangle size={20} className="mr-2" /> API密钥未配置或无效。请检查控制台获取更多信息。
        </div>
      )}
    </div>
  );
};

export default App;
